import os

os.system("python3 src/passwordbf.py")